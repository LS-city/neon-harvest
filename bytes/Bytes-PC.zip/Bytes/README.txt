BYTES - roleplay wallet for VRChat
==================================
Bytes are play money for roleplay. They have no real-world value and can't be
bought, sold or cashed out.

What it does
- Send, tip or pay Bytes to anyone by their Bytes name.
- Start a group, add roles with wages, hire staff, pay one person or everyone.
- Shows your name, job and group above your head in VRChat, and pops up
  "Tip +25 Bytes from ..." when you get paid.

SETUP (once)
1. Install Node.js (LTS) from https://nodejs.org if you don't have it.
2. In VRChat: Action Menu > Options > OSC > Enabled.

EVERY TIME
1. Double-click "Start Bytes.bat". Leave the black window open.
2. Your browser opens http://localhost:7778. Sign in.
3. First time: pick your Bytes name (use your VRChat name). You start with 100.
4. Chatbox tab > "Start showing in VRChat".

STANDALONE HEADSET (Quest without a PC cable)
Run Bytes on any PC or laptop on the same Wi-Fi. On the Chatbox tab choose
"A standalone headset on my Wi-Fi" and type the headset's IP address
(Quest: Settings > Wi-Fi > your network > IP address). Turn OSC on in VRChat
on the headset. If nothing shows, allow Node.js through Windows Firewall.

USING THE WEB WALLET WITH THE PC APP
You can also use https://ls-city.github.io/neon-harvest/bytes/ in your browser.
While the black Bytes window is open, the web wallet finds the PC app and its
"Start showing in VRChat" button works too. If the browser asks to reach
devices on your network, click Allow.

IF WINDOWS BLOCKS THE .BAT
Right-click "Start Bytes.bat" > Properties > tick "Unblock" > OK.
Or click "More info" > "Run anyway" on the blue box.

PHONE ONLY
Use the web wallet in your phone's browser to send, tip, pay and manage jobs.
It can't type into VRChat by itself; copy your line from the Chatbox tab.

Only run one chatbox app at a time (Bytes, NEON HARVEST Link or MagicChatbox).

FREE vs PRO
Free for everyone: wallet, send / tip / pay, history, working a job, chatbox.
Bytes Pro (supporters): start groups, staff roles, wages, hiring, payroll,
and a star next to your name. Bytes themselves are never sold.

FOR THE GAME OWNER
Pro is switched on by hand: Admin tab > "Bytes Pro supporters" > type the
supporter's Bytes name and how many months > Give Pro.
To show a Patreon button, open bytes.html in Notepad, find PATREON_URL near
the bottom and paste your Patreon link between the quotes.

bytes.rules.txt holds the security rules Bytes needs. They go inside the
project's Firestore rules, just before the last two closing braces.
