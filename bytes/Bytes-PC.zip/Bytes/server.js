// Bytes: roleplay wallet for VRChat. Shows your name, job and tips in the VRChat chatbox.
// Runs on your own PC. Needs Node.js (no extra installs). Talks to VRChat with OSC, VRChat's official feature for outside apps.
"use strict";
const http = require("http"), dgram = require("dgram"), fs = require("fs"), path = require("path"), { exec } = require("child_process");

const PORT = 7778;               // the Bytes page: http://localhost:7778
const VRC_HOST = "127.0.0.1";    // VRChat on this same PC
const VRC_PORT = 9000;           // VRChat's OSC input port (default)

const udp = dgram.createSocket("udp4");

// --- OSC message encoding (tiny, no libraries) ---
function oscString(s) { const b = Buffer.from(s + "\0", "utf8"); const pad = (4 - (b.length % 4)) % 4; return Buffer.concat([b, Buffer.alloc(pad)]); }
function oscMessage(address, args) {
  let tags = ","; const parts = [];
  for (const a of args) {
    if (typeof a === "string") { tags += "s"; parts.push(oscString(a)); }
    else if (a === true) tags += "T";
    else if (a === false) tags += "F";
    else if (Number.isInteger(a)) { tags += "i"; const b = Buffer.alloc(4); b.writeInt32BE(a); parts.push(b); }
    else if (typeof a === "number") { tags += "f"; const b = Buffer.alloc(4); b.writeFloatBE(a); parts.push(b); }
  }
  return Buffer.concat([oscString(address), oscString(tags), ...parts]);
}
// Where to send: this PC by default, or a standalone headset on the same home network.
// Only private (home network) addresses are accepted.
function okHost(h) {
  if (typeof h !== "string" || !/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return false;
  const o = h.split(".").map(Number); if (o.some(n => n > 255)) return false;
  return o[0] === 127 || o[0] === 10 || (o[0] === 192 && o[1] === 168) || (o[0] === 172 && o[1] >= 16 && o[1] <= 31);
}
function send(address, args, host) { const m = oscMessage(address, args); udp.send(m, VRC_PORT, host || VRC_HOST); return m; }

// VRChat chatbox: max 144 characters. args = text, send now (skip keyboard), play notification sound.
function chatbox(text, sound, host) { return send("/chatbox/input", [String(text).slice(0, 144), true, !!sound], host); }

const PAGE = path.join(__dirname, "bytes.html");
const VERSION = 2;
// Pages allowed to drive the chatbox: this app's own page and the Bytes web wallet.
const ALLOWED = new Set(["http://localhost:" + PORT, "http://127.0.0.1:" + PORT, "https://ls-city.github.io"]);
const server = http.createServer((req, res) => {
  // Only accept requests from this PC.
  if (!["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(req.socket.remoteAddress)) { res.writeHead(403); return res.end(); }
  const origin = req.headers.origin;
  if (origin) {
    if (!ALLOWED.has(origin)) { res.writeHead(403); return res.end(); }
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
  }
  if (req.method === "OPTIONS") {
    res.writeHead(204, { "Access-Control-Allow-Methods": "GET, POST", "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Allow-Private-Network": "true", "Access-Control-Max-Age": "600" });
    return res.end();
  }
  if (req.method === "GET" && req.url === "/ping") {
    res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
    return res.end(JSON.stringify({ ok: true, app: "bytes", v: VERSION }));
  }
  if (req.method === "GET" && (req.url === "/" || req.url.startsWith("/?"))) {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    return fs.createReadStream(PAGE).pipe(res);
  }
  if (req.method === "POST" && (req.url === "/chatbox" || req.url === "/clear")) {
    let body = ""; req.on("data", c => { body += c; if (body.length > 4000) req.destroy(); });
    req.on("end", () => {
      try {
        const { text, sound, host } = JSON.parse(body || "{}");
        if (host !== undefined && host !== "" && !okHost(host)) throw 0;
        if (req.url === "/clear") chatbox("", false, host || undefined);
        else { if (typeof text !== "string") throw 0; chatbox(text, sound === true, host || undefined); }
        res.writeHead(200, { "Content-Type": "application/json" }); res.end('{"ok":true}');
      } catch (e) { res.writeHead(400); res.end('{"ok":false}'); }
    });
    return;
  }
  res.writeHead(404); res.end();
});

if (require.main === module) {
  server.listen(PORT, "127.0.0.1", () => {
    const url = `http://localhost:${PORT}`;
    console.log("");
    console.log("  Bytes is running.");
    console.log("  Open " + url + " if it didn't open by itself.");
    console.log("  Sending to VRChat on " + VRC_HOST + ":" + VRC_PORT + " (turn on OSC in VRChat's Action Menu > Options > OSC).");
    console.log("  Close this window to stop.");
    console.log("");
    if (process.platform === "win32" && !process.argv.includes("--no-open")) exec(`start "" "${url}"`);
  });
  server.on("error", e => { console.error(e.code === "EADDRINUSE" ? "Bytes is already running. Open http://localhost:" + PORT : e); });
}
module.exports = { oscMessage };
